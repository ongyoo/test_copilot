//
//  ScanOverlayView.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 1/5/2568 BE.
//

import UIKit

final class ScanOverlayView: UIView {
    private let scanBox = UIView()
    private let scanLine = UIView()
    private var scanAnimation: CABasicAnimation?

    private let boxSizeRatio: CGFloat = 0.6 // 60% this screen

    override init(frame: CGRect) {
        super.init(frame: frame)
        backgroundColor = .clear
        setupBox()
        setupLine()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        backgroundColor = .clear
        setupBox()
        setupLine()
    }

    private func setupBox() {
        addSubview(scanBox)
        scanBox.layer.borderColor = UIColor.green.withAlphaComponent(0.8).cgColor
        scanBox.layer.borderWidth = 2
        scanBox.layer.cornerRadius = 12
        scanBox.backgroundColor = UIColor.clear
    }

    private func setupLine() {
        scanLine.backgroundColor = UIColor.green.withAlphaComponent(0.6)
        scanLine.layer.cornerRadius = 1
        scanBox.addSubview(scanLine)
    }

    override func layoutSubviews() {
        super.layoutSubviews()

        // กำหนดขนาดกรอบ scan ตรงกลาง
        let width = bounds.width * boxSizeRatio
        let height = width
        let originX = (bounds.width - width) / 2
        let originY = (bounds.height - height) / 2
        scanBox.frame = CGRect(x: originX, y: originY, width: width, height: height)

        // เส้นเลเซอร์
        let lineHeight: CGFloat = 2
        scanLine.frame = CGRect(x: 0, y: 0, width: width, height: lineHeight)
    }

    func startAnimating() {
        stopAnimating()

        let animation = CABasicAnimation(keyPath: "position.y")
        animation.fromValue = 0
        animation.toValue = scanBox.bounds.height
        animation.duration = 2.0
        animation.repeatCount = .infinity
        animation.autoreverses = false
        scanLine.layer.add(animation, forKey: "scanLineAnimation")

        scanAnimation = animation
    }

    func stopAnimating() {
        scanLine.layer.removeAllAnimations()
    }
}

