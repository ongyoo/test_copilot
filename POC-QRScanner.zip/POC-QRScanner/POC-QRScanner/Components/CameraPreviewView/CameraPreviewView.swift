//
//  CameraPreviewView.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 1/5/2568 BE.
//

import UIKit
import AVFoundation

final class CameraPreviewView: UIView {
    private var previewLayer: CALayer?
    private let overlay = ScanOverlayView()

    override init(frame: CGRect) {
        super.init(frame: frame)
        commonInit()
    }

    required init?(coder: NSCoder) {
        super.init(coder: coder)
        commonInit()
    }

    private func commonInit() {
        clipsToBounds = true
        addSubview(overlay)
        overlay.translatesAutoresizingMaskIntoConstraints = false
        NSLayoutConstraint.activate([
            overlay.topAnchor.constraint(equalTo: topAnchor),
            overlay.bottomAnchor.constraint(equalTo: bottomAnchor),
            overlay.leadingAnchor.constraint(equalTo: leadingAnchor),
            overlay.trailingAnchor.constraint(equalTo: trailingAnchor),
        ])
    }

    func setPreviewLayer(_ layer: CALayer) {
        previewLayer?.removeFromSuperlayer()
        previewLayer = layer
        layer.frame = bounds
        layer.contentsGravity = .resizeAspectFill
        self.layer.insertSublayer(layer, at: 0)
    }

    override func layoutSubviews() {
        super.layoutSubviews()
        previewLayer?.frame = bounds
    }

    func startScanAnimation() {
        overlay.startAnimating()
    }

    func stopScanAnimation() {
        overlay.stopAnimating()
    }
}
