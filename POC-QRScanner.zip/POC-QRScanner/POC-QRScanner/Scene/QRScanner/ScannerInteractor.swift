//
//  ScannerInteractor.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 1/5/2568 BE.
//

import Foundation

final class ScannerInteractor {
    private let scanner: QRScannerService
    var presenter: ScannerPresenter?

    init(presenter: ScannerPresenter?, scanner: QRScannerService = QRScannerFactory.makeScanner()) {
        self.presenter = presenter
        self.scanner = scanner
    }

    func startScanning() {
        scanner.startScanning { [weak self] code in
            guard let self else { return }
            presenter?.presentDetectedCode(code)
        }
        presenter?.presentPreview(scanner.previewLayer)
    }

    func stopScanning() {
        scanner.stopScanning()
    }
}
