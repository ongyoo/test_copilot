//
//  ScannerPresenter.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 1/5/2568 BE.
//

import Foundation
import QuartzCore

final class ScannerPresenter {
    weak var viewController: ScannerViewController?
    
    init(viewController: ScannerViewController? = nil) {
        self.viewController = viewController
    }

    func presentPreview(_ layer: CALayer) {
        viewController?.displayPreviewLayer(layer)
    }

    func presentDetectedCode(_ code: String) {
        viewController?.displayDetectedQRCode(code)
    }
}
