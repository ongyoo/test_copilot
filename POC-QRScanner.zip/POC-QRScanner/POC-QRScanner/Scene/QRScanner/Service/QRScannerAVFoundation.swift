//
//  QRScannerAVFoundation.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 1/5/2568 BE.
//

import AVFoundation
import UIKit

final class QRScannerAVFoundation: NSObject, QRScannerService {
    private let session = AVCaptureSession()
    private var onDetect: ((String) -> Void)?

    var previewLayer: CALayer {
        AVCaptureVideoPreviewLayer(session: session)
    }

    func startScanning(onDetect: @escaping (String) -> Void) {
        self.onDetect = onDetect

        guard let device = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else { return }

        session.beginConfiguration()
        session.sessionPreset = .hd1920x1080 // เร่งความละเอียด

        let output = AVCaptureMetadataOutput()
        if session.canAddOutput(output) {
            session.addOutput(output)
            output.setMetadataObjectsDelegate(self, queue: .main)
            output.metadataObjectTypes = [.qr]

            // Set crop zone กลางจอ
            let centerRect = CGRect(x: 0.25, y: 0.25, width: 0.5, height: 0.5)
            output.rectOfInterest = centerRect
        }

        session.addInput(input)
        session.commitConfiguration()
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            session.startRunning()
        }
    }

    func stopScanning() {
        session.stopRunning()
    }
}

extension QRScannerAVFoundation: AVCaptureMetadataOutputObjectsDelegate {
    func metadataOutput(_ output: AVCaptureMetadataOutput,
                        didOutput metadataObjects: [AVMetadataObject],
                        from connection: AVCaptureConnection) {
        guard let object = metadataObjects.first as? AVMetadataMachineReadableCodeObject,
              let value = object.stringValue else { return }
        stopScanning()
        onDetect?(value)
    }
}

