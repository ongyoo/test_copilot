//
//  QRScannerService.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 1/5/2568 BE.
//

import Foundation
import QuartzCore

protocol QRScannerService {
    var previewLayer: CALayer { get }
    func startScanning(onDetect: @escaping (String) -> Void)
    func stopScanning()
}

final class QRScannerFactory {
    static func makeScanner() -> QRScannerService {
        if #available(iOS 12, *) {
            return QRScannerVisionKit()
        } else {
            return QRScannerAVFoundation()
        }
    }
}
