//
//  QRScannerVisionKit.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 1/5/2568 BE.
//

/*
import Vision
import VisionKit
import AVFoundation
import UIKit

final class QRScannerVisionKit: NSObject, QRScannerService {
    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private var request: VNDetectBarcodesRequest?
    private var onDetect: ((String) -> Void)?

    var previewLayer: CALayer {
        AVCaptureVideoPreviewLayer(session: session)
    }

    func startScanning(onDetect: @escaping (String) -> Void) {
        self.onDetect = onDetect

        guard let device = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else { return }

        session.beginConfiguration()
        session.sessionPreset = .vga640x480
        //session.sessionPreset = .hd1920x1080

        if session.canAddOutput(videoOutput) {
            session.addOutput(videoOutput)
            videoOutput.setSampleBufferDelegate(self, queue: .main)
        }

        session.addInput(input)
        session.commitConfiguration()
        
        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            session.startRunning()
        }

        // ✅ Create and assign VNDetectBarcodesRequest with max supported revision (v1–v4)
        let request = VNDetectBarcodesRequest(completionHandler: handleDetection)
        if let maxSupportedRevision = VNDetectBarcodesRequest.supportedRevisions.max() {
            request.revision = maxSupportedRevision
        } else {
            request.revision = VNDetectBarcodesRequest.defaultRevision
        }
        self.request = request
    }

    func stopScanning() {
        session.stopRunning()
    }

    private func handleDetection(request: VNRequest, error: Error?) {
        guard let results = request.results as? [VNBarcodeObservation],
              let payload = results.first?.payloadStringValue else { return }

        stopScanning()
        onDetect?(payload)
    }
}

extension QRScannerVisionKit: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        guard let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
              let request = request else { return }

        let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
        try? handler.perform([request])
    }
}

*/

import Vision
import VisionKit
import AVFoundation
import UIKit
import MLKitBarcodeScanning
import MLKitVision

final class QRScannerVisionKit: NSObject, QRScannerService {
    private let session = AVCaptureSession()
    private let videoOutput = AVCaptureVideoDataOutput()
    private var visionRequest: VNDetectBarcodesRequest?
    private var mlKitScanner: BarcodeScanner!
    private var onDetect: ((String) -> Void)?
    private var hasDetected = false // ป้องกัน detect ซ้ำ

    var previewLayer: CALayer {
        AVCaptureVideoPreviewLayer(session: session)
    }

    func startScanning(onDetect: @escaping (String) -> Void) {
        self.onDetect = onDetect
        self.hasDetected = false

        guard let device = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else { return }

        session.beginConfiguration()
        //session.sessionPreset = .hd1920x1080
        session.sessionPreset = .high

        if session.canAddOutput(videoOutput) {
            session.addOutput(videoOutput)
            videoOutput.setSampleBufferDelegate(self, queue: .main)
        }

        session.addInput(input)
        session.commitConfiguration()

        DispatchQueue.global(qos: .userInitiated).async { [weak self] in
            guard let self else { return }
            session.startRunning()
        }

        // VisionKit Request (v1-v4)
        let request = VNDetectBarcodesRequest(completionHandler: handleVisionDetection)
        if let maxSupportedRevision = VNDetectBarcodesRequest.supportedRevisions.max() {
            request.revision = maxSupportedRevision
        }
        self.visionRequest = request

        // MLKit Scanner Setup
        let formatOptions = BarcodeFormat.all
        let options = BarcodeScannerOptions(formats: formatOptions)
        self.mlKitScanner = BarcodeScanner.barcodeScanner(options: options)
    }

    func stopScanning() {
        session.stopRunning()
    }

    // MARK: - VisionKit Handler
    private func handleVisionDetection(request: VNRequest, error: Error?) {
        guard //!hasDetected,
              let results = request.results as? [VNBarcodeObservation],
              let payload = results.first?.payloadStringValue else { return }

        print("VisionKit detected: \(payload)")  // Log สำหรับ VisionKit
        hasDetected = true
        stopScanning()
        onDetect?(payload)
    }

    // MARK: - MLKit Handler
    private func handleMLKitDetection(sampleBuffer: CMSampleBuffer) {
        guard //!hasDetected,
              let _ = CMSampleBufferGetImageBuffer(sampleBuffer) else { return }

        let visionImage = VisionImage(buffer: sampleBuffer)
        visionImage.orientation = .right

        mlKitScanner.process(visionImage) { [weak self] barcodes, error in
            guard let self = self, !self.hasDetected,
                  let barcode = barcodes?.first,
                  let value = barcode.rawValue else { return }

            print("MLKit detected: \(value)")  // Log สำหรับ MLKit
            self.hasDetected = true
            self.stopScanning()
            self.onDetect?(value)
        }
    }
}

// MARK: - AVCapture Delegate
extension QRScannerVisionKit: AVCaptureVideoDataOutputSampleBufferDelegate {
    func captureOutput(_ output: AVCaptureOutput,
                       didOutput sampleBuffer: CMSampleBuffer,
                       from connection: AVCaptureConnection) {
        // VisionKit
        if let pixelBuffer = CMSampleBufferGetImageBuffer(sampleBuffer),
           let visionRequest = visionRequest {
            let handler = VNImageRequestHandler(cvPixelBuffer: pixelBuffer, options: [:])
            try? handler.perform([visionRequest])
        }

        // MLKit
        handleMLKitDetection(sampleBuffer: sampleBuffer)
    }
}


