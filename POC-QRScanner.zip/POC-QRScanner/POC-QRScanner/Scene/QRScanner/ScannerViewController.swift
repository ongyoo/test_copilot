//
//  ScannerViewController.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 1/5/2568 BE.
//

import UIKit
import AVFoundation

final class ScannerViewController: UIViewController {
    @IBOutlet private weak var cameraPreview: CameraPreviewView!
    var interactor: ScannerInteractor?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        interactor = ScannerInteractor(presenter: ScannerPresenter(viewController: self))
        interactor?.startScanning()
    }

    func displayPreviewLayer(_ layer: CALayer) {
        layer.frame = cameraPreview.bounds
        cameraPreview.setPreviewLayer(layer)
    }

    func displayDetectedQRCode(_ code: String) {
        let alert = UIAlertController(title: "QR Detected", message: code, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { [weak self] _ in
            guard let self else { return }
            interactor?.stopScanning()
            interactor?.startScanning()
        }))
        present(alert, animated: true)
        AudioServicesPlaySystemSound(SystemSoundID(kSystemSoundID_Vibrate))
    }
}
