//
//  ScannerView.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 6/5/2568 BE.
//

import UIKit

final class ScannerView: UIView {

}
