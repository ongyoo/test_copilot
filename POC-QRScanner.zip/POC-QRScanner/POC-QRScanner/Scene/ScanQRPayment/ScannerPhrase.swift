//
//  ScannerPhrase.swift
//  POC-QRScanner
//
//  Created by Komsit Chusangthong on 6/5/2568 BE.
//

//import Common

struct ScannerPhrase {
    static var labelPayQR: String {
        "Pay with QR/Barcode"
        //Base.phrases.getContent(forKey: "label_pay_qr") ?? "Pay with QR/Barcode"
    }
    static var labelScanQR: String {
        "Place QR or Barcode in the\\n middle of the screen"
        //Base.phrases.getContent(forKey: "label_scan_qr") ?? "Place QR or Barcode in the\\n middle of the screen"
    }
}
